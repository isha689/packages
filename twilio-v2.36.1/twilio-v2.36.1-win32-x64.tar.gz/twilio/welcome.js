/* eslint-disable no-console */
console.log();
console.log('*************************************************************************');
console.log('*                                                                       *');
console.log('* To get started, please create a twilio-cli profile:                   *');
console.log('*                                                                       *');
console.log('*     twilio login                                                      *');
console.log('*                                                                       *');
console.log('*     OR                                                                *');
console.log('*                                                                       *');
console.log('*     twilio profiles:create                                            *');
console.log('*                                                                       *');
console.log('*************************************************************************');
console.log();
